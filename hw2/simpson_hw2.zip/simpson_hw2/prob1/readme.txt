Deverick Simpson
Yuekun Yang

Filename:
	 semaphore.c

Testing:
	To test semaphore.c, please first compile the file as follows, 
		gcc semaphore.c -lpthread
		./a.out

		The results of this will print the producer insert 
		and the consumer removal of the character 'X'

Completion:
	Coding completion took approximately 3 hours however there were
	a few errors that continued that time a bit further.  

	Note:
		This time does not include the added time to read 
		documentation and references.

Difficulty:
	0-5 Scale:  2
		The concept and idea was fairly easy to follow and there was
		consistent documentation provided on the POSIX library
Prior knowledge:
	Outside of discussions within the classroom, not much practice has been had with 		multithreading applications.  
