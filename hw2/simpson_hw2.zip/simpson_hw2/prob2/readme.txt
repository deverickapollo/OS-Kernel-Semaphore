Deverick Simpson
Yuekun Yang

Filename:
	 monitor.c
	 pro_con.c

Testing:
	To test monitor.c, please first compile the file as follows, 
		gcc monitor.c -lpthread
		./a.out

		The results are not complete as the program was not finished in time of submission.

Completion:
	Coding completion took approximately the majority of a day to review documentation and 		attempt implementing within the c environment. 

	

Difficulty:
	0-5 Scale:  4
		The assignment required a bit more time than I had anticipated and originally 			planned. Had I negotiated time a bit better, the assignment would have been 			complete.


Prior knowledge:
	Outside of discussions within the classroom, not much practice has been had with 		multithreading applications dealing with the semaphore library or monitors.
