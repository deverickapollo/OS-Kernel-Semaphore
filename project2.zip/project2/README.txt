README.txt
---------------------------------------------------------


handler.c
assembly.S

To compile the program, first install the necessary Altera libraries and software.  After attaching an altera device and loading a .sof using Programmer, configure the run file to run on the NIOS hardware.  

Once compiled within the NIOS II eclipse environment, assembly.S will be linked to the object files of handler.c. To run, select the run configuration installed previously.  Output will appear within the console.
